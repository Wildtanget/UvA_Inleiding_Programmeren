/*******************************************************************************
 * Naam: Noureddine Tahtahi
 * UvAnetID: 15861325
 * Studie: BSc Informatica
 *
 * opdracht3.c:
 * Dit programma simuleert Conway's Game of Life in de terminal, dit wordt
 * gedaan door eerst een grid te initialiseren met een van te voren
 * geselecteerd patroon. Vervolgens kunnen toekomstige generaties berekent en
 * weergegeven worden.
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*******************************************************************************
 * Spel eigenschappen:
 *
 * MAX_OPDRACHT_LEN is de maximale lengte van de input, BREEDTE en HOOGTE zijn
 * de afmetingen van de grid. LEVEND en DOOD zijn de toestanden waar een cel
 * zich in kan bevinden.
 ******************************************************************************/
#define MAX_OPDRACHT_LEN 100
#define BREEDTE 79
#define HOOGTE 40
#define LEVEND 1
#define DOOD 0

enum patroon {
    OSCILLATOR = 1,
    GLIDER,
    GOSPER
};

/*******************************************************************************
 * Plaatst een oscillator in de grid, dit is een patroon die periodisch
 * terugkeert naar het beginpatroon.
 *
 * Voorbeeld: init_oscillator -> *
 *                               **
 *                               **
 *                                *
 ******************************************************************************/
void init_oscillator(int grid[HOOGTE][BREEDTE]) {
    for (int i = 1; i < 4; i++) {
        grid[i][2] = LEVEND;
        grid[i + 1][3] = LEVEND;
    }
}

/*******************************************************************************
 * Plaatst een glider in de grid, dit is een patroon die zelf voort beweegt.
 *
 * Voorbeeld: init_glider(grid) ->  *
 *                                   *
 *                                 ***
 ******************************************************************************/
void init_glider(int grid[HOOGTE][BREEDTE]) {
    for (int i = 0; i < 3; i++) {
        grid[4][i + 1] = LEVEND;
        if (i > 0) {
            grid[i + 1][i + 1] = LEVEND;
        }
    }
}

/*******************************************************************************
 * Plaatst een 2x2 blok op positie (x, y).
 *
 * x: Het x-coördinaat waarop het blok begint.
 * y: het y-coördinaat waarop het blok begint.
 *
 * Voorbeeld: plaats_blok -> **
 *                           **
 ******************************************************************************/
void plaats_blok(int grid[HOOGTE][BREEDTE], int x, int y) {
    for (int i = 0; i < 2; i++) {
        grid[y][x + i] = LEVEND;
        grid[y + 1][x + i] = LEVEND;
    }
}

/*******************************************************************************
 * Plaatst de linker shuttle van een Gosper Gun op positie (x, y).
 *
 * grid: Grid dat geinitialiseert moet worden.
 * x: x-coördinaat waar de linker shuttle geplaatst zal worden.
 * y: y-coördinaat waar de linker shuttle geplaatst zal worden.
 *
 * Voorbeeld: plaats_linker_shuttle(grid, x, y) ->   **
 *                                                  *   *
 *                                                 *     *
 *                                                 *   * **
 *                                                 *     *
 *                                                  *   *
 *                                                   **
 ******************************************************************************/
void plaats_linker_shuttle(int grid[HOOGTE][BREEDTE], int x, int y) {
    for (int i = 0; i < 8; i++) {
        if (i == 0 || i == 4 || i == 6 || i == 7) {
            grid[y][x + i] = LEVEND;
        }
        if (i == 0 || i == 6) {
            grid[y - 1][x + i] = LEVEND;
            grid[y + 1][x + i] = LEVEND;
        } else if (i == 1 || i == 5) {
            grid[y - 2][x + i] = LEVEND;
            grid[y + 2][x + i] = LEVEND;
        } else if (i == 2 || i == 3) {
            grid[y - 3][x + i] = LEVEND;
            grid[y + 3][x + i] = LEVEND;
        }
    }
}

/*******************************************************************************
 * Plaatst de rechter shuttle van een Gosper Gun op positie (x, y).
 *
 * grid: Grid dat geinitialiseert moet worden.
 * x: x-coördinaat waar de rechter shuttle geplaatst zal worden.
 * y: y-coördinaat waar de rechter shuttle geplaatst zal worden.
 *
 * Voorbeeld: plaats_rechter_shuttle(grid, x, y) ->     *
 *                                                    * *
 *                                                  **
 *                                                  **
 *                                                  **
 *                                                    * *
 *                                                      *
 ******************************************************************************/
void plaats_rechter_shuttle(int grid[HOOGTE][BREEDTE], int x, int y) {
    for (int i = 0; i < 8; i++) {
        if (i == 1 || i == 2) {
            grid[y - 1][x + i] = LEVEND;
            grid[y][x + i] = LEVEND;
            grid[y + 1][x + i] = LEVEND;
        } else if (i == 3 || i == 5) {
            grid[y - 2][x + i] = LEVEND;
            grid[y + 2][x + i] = LEVEND;
        }
        if (i == 5) {
            grid[y - 3][x + i] = LEVEND;
            grid[y + 3][x + i] = LEVEND;
        }
    }
}

/*******************************************************************************
 * Initialiseert de grid met een Gosper Gun die periodisch glider's genereert.
 * Een Gosper Gun bestaat uit 2 blokken en 2 shuttles die tussen de blokken
 * bewegen. Op de plek waar de shuttles botsen zullen gliders gegenereerd
 * worden.
 *
 * grid: Grid dat geinitialiseert moet worden.
 ******************************************************************************/
void init_gosper(int grid[HOOGTE][BREEDTE]) {
    plaats_blok(grid, 1, 5);
    plaats_blok(grid, 35, 3);
    plaats_linker_shuttle(grid, 11, 6);
    plaats_rechter_shuttle(grid, 20, 4);
}

/*******************************************************************************
 * Initaliseert de grid met het gewenste patroon. Oscillator(1) is een patroon
 * die na een aantal generaties terugkeert naar zijn startpatroon, glider(2) is
 * een patroon die zich diagonaal voort beweegt en gosper(3) is een patroon die
 * periodisch glider's genereert.
 *
 * grid[][]: Een tweedimensionaal grid waarin cellen dood of levend kunnen zijn.
 * patroon: Het gewenste patroon dat geinitialiseert wordt.
 ******************************************************************************/
void initialiseer_grid(int grid[HOOGTE][BREEDTE], int patroon) {
    memset(grid, 0, sizeof(grid[HOOGTE][BREEDTE]));

    if (patroon == OSCILLATOR) {
        init_oscillator(grid);
    } else if (patroon == GLIDER) {
        init_glider(grid);
    } else if (patroon == GOSPER) {
        init_gosper(grid);
    }
}

/*******************************************************************************
 * Print het generatienummer en de bijbehorende grid. Voor levende cellen wordt
 * een '*' gebruikt en voor dode cellen een '.'.
 *
 * grid[][]: Een tweedimensionaal grid waarin cellen dood of levend kunnen zijn.
 * generatie: Het huidige generatienummer.
 ******************************************************************************/
void toon(const int grid[HOOGTE][BREEDTE], int generatie) {
    printf("\nGeneratie %d:\n", generatie);

    for (int y = 0; y < HOOGTE; y++) {
        for (int x = 0; x < BREEDTE; x++) {
            if (grid[y][x] == DOOD) {
                printf(".");
            } else {
                printf("*");
            }
        }
        printf("\n");
    }
}

/*******************************************************************************
 * Kopiërt de volledige inhoud van bron_grid naar doel_grid, deze hebben
 * dezelfde afmetingen.
 *
 * bron_grid: Grid waar de inhoud van wordt gekopiërd.
 * doel_grid: Grid waar de inhoud naar wordt gekopiërd.
 ******************************************************************************/
void kopie(const int bron_grid[HOOGTE][BREEDTE], int doel_grid[HOOGTE][BREEDTE]) {
    memcpy(doel_grid, bron_grid, sizeof(int) * HOOGTE * BREEDTE);
}

/*******************************************************************************
 * Telt het aantal buren (levende cellen), om een specifieke cel heen. Hierbij
 * moet er opgelet worden dat het enkel naar cellen kijkt die zich binnen de
 * grid bevinden.
 *
 * grid[][]: Een tweedimensionaal grid waarin cellen dood of levend kunnen zijn.
 * x: Het x-coördinaat van de cel waarvan het aantal buren wordt geteld.
 * y: Het y-coördinaat van de cel waarvan het aantal buren wordt geteld.
 *
 * Uitvoer: Het aantal buren om de cel (x, y) heen.
 *
 * Voorbeeld: Stel grid heeft een blok die begint op (0, 0).
 *            buren(grid, 0, 0) -> 3
 ******************************************************************************/
int buren(const int grid[HOOGTE][BREEDTE], int x, int y) {
    int buren;

    buren = 0;
    for (int i = y - 1; i <= y + 1 && i < HOOGTE; i++) {
        if (i < 0) {
            i++;
        }
        for (int j = x - 1; j <= x + 1 && j < BREEDTE; j++) {
            if (j < 0) {
                j++;
            }
            if (grid[i][j] == LEVEND && (i != y || j != x)) {
                buren++;
            }
        }
    }
    return buren;
}

/*******************************************************************************
 * Bepaalt de volgende generatie aan de hand van oud_grid en slaat dit op in
 * nieuw_grid. Als de de cel in oud_grid levend is en 2 buren heeft dan blijft
 * deze cel in nieuw_grid ook leven. Als de cel in oud_grid dood is en 3 buren
 * heeft, dan komt deze cel in nieuw_grid tot leven. Anders gaat de cel dood.
 *
 * oud_grid: Grid waarmee de volgende generatie wordt bepaald.
 * nieuw_grid: Grid waarin de volgende generatie wordt opgeslagen.
 ******************************************************************************/
void stap(const int oud_grid[HOOGTE][BREEDTE], int nieuw_grid[HOOGTE][BREEDTE]) {
    int aantal;

    for (int y = 0; y < HOOGTE; y++) {
        for (int x = 0; x < BREEDTE; x++) {
            aantal = buren(oud_grid, x, y);
            if (aantal == 3 || (aantal == 2 && oud_grid[y][x] == LEVEND)) {
                nieuw_grid[y][x] = LEVEND;
            } else {
                nieuw_grid[y][x] = DOOD;
            }
        }
    }
}


/* Hoofdprogramma.

   Het initialiseert en toont eerst de begintoestand van het grid. (Je kunt
   eventueel als je het programma opstart opgeven welk beginpatroon moet
   worden gebruikt.)

   Vervolgens kun je telkens opgeven hoeveel generaties de computer moet
   doorberekenen, door het aantal generaties in te typen dat er moet worden
   doorberekend.

   Als je op Enter drukt zonder een getal in te vullen zal de computer de
   eerstvolgende generatie tonen.

   Druk op Ctrl+D om het programma te beeindigen.
*/
#ifndef COMPILE_MAIN
int main(int argc, char *argv[]) {
    char buffer[MAX_OPDRACHT_LEN];
    int grid[HOOGTE][BREEDTE];
    int nieuw_grid[HOOGTE][BREEDTE];

    int patroon = argc == 1 ? 1 : atoi(argv[1]);
    initialiseer_grid(grid, patroon);
    int generatie = 0;

    printf("Conway's Game of life\n\n");
    toon(grid, generatie);
    while (1) {
        printf("\nGeef een opdracht:\n");
        char *res = fgets(buffer, MAX_OPDRACHT_LEN, stdin);
        if (res == NULL) {
            // Er is waarschijnlijk op Ctrl+D gedrukt.
            printf("Programma wordt beëindigd.\n");
            break;
        }
        int aantal_generaties = buffer[0] == '\n' ? 1 : atoi(buffer);
        for (int i = 0; i < aantal_generaties; i++) {
            stap(grid, nieuw_grid);
            kopie(nieuw_grid, grid);
        }
        generatie += aantal_generaties;
        toon(grid, generatie);
    }
    return 0;
}
#endif
